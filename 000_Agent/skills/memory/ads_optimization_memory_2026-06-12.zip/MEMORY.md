# Memory Index

- [user_profile.md](user_profile.md) — 使用者背景：數位廣告從業者，使用繁體中文，偏好 Python 開發
- [project_ad_agent.md](project_ad_agent.md) — 數位廣告 AI Agent 專案概況與架構
- [feedback_spreadsheet_tools.md](feedback_spreadsheet_tools.md) — 試算表：用 gviz CSV API 讀資料，browser_batch 批次執行，不截圖導覽
- [project_daily_report.md](project_daily_report.md) — 每日 Meta 廣告日報自動化：御熹堂＋毛孩時代，每天 9AM 發至 Google Chat
- [project_ads_optimization_training.md](project_ads_optimization_training.md) — 目標2026-08前AI廣告優化判斷達人類90分，持續回饋訓練
- [feedback_ads_optimization.md](feedback_ads_optimization.md) — 廣告優化建議回饋紀錄（AI vs 人類落差校正）
